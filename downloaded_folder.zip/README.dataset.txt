# cat detector > 2024-02-23 5:03pm
https://universe.roboflow.com/maryam-irshad-pnwot/cat-detector-rebcb

Provided by a Roboflow user
License: CC BY 4.0

